#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x20 (0x20 - 0x0)
// Function ALI_NPC_HairCloth.ALI_NPC_HairCloth_C.NPC_HairClothLayer
struct IALI_NPC_HairCloth_C_NPC_HairClothLayer_Params
{
public:
	struct FPoseLink                             InPose;                                            // 0x0(0x10)(BlueprintVisible, BlueprintReadOnly, Parm, NoDestructor)
	struct FPoseLink                             NPC_HairClothLayer;                                // 0x10(0x10)(Parm, OutParm, NoDestructor)
};

}
}


