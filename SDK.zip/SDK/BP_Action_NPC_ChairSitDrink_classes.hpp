#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x180 - 0x180)
// BlueprintGeneratedClass BP_Action_NPC_ChairSitDrink.BP_Action_NPC_ChairSitDrink_C
class UBP_Action_NPC_ChairSitDrink_C : public UBP_Action_NPC_HasPropMonoMotion_C
{
public:

	static class UClass* StaticClass();
	static class UBP_Action_NPC_ChairSitDrink_C* GetDefaultObj();

};

}


