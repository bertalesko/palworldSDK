#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x490 - 0x490)
// BlueprintGeneratedClass BP_ActionSitRide.BP_ActionSitRide_C
class UBP_ActionSitRide_C : public UBP_ActionRideBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionSitRide_C* GetDefaultObj();

};

}


