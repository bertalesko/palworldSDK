#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x168 - 0x168)
// BlueprintGeneratedClass BP_ActionCool.BP_ActionCool_C
class UBP_ActionCool_C : public UBP_ActionSimpleMonoMontage_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionCool_C* GetDefaultObj();

};

}


