#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x490 - 0x490)
// BlueprintGeneratedClass BP_ActionHumanRide.BP_ActionHumanRide_C
class UBP_ActionHumanRide_C : public UBP_ActionRideBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionHumanRide_C* GetDefaultObj();

};

}


