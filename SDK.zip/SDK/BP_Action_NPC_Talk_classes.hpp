#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x168 - 0x168)
// BlueprintGeneratedClass BP_Action_NPC_Talk.BP_Action_NPC_Talk_C
class UBP_Action_NPC_Talk_C : public UBP_ActionSimpleMonoMontage_C
{
public:

	static class UClass* StaticClass();
	static class UBP_Action_NPC_Talk_C* GetDefaultObj();

};

}


